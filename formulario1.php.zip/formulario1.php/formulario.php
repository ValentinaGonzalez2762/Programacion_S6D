<?php
// formulario.php - versión corregida

// Conexión a la base de datos
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "miformulario_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    // Mostrar error claro si falla la conexión
    die("<p style='color:red; text-align:center;'>Error de conexión: " . htmlspecialchars($conn->connect_error) . "</p>");
}

$msg = ""; // Mensaje que mostraremos en la página resultante

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recibir y sanitizar datos
    $nombre    = isset($_POST['nombre']) ? htmlspecialchars($_POST['nombre']) : '';
    $correo    = isset($_POST['correo']) ? htmlspecialchars($_POST['correo']) : '';
    $telefono  = isset($_POST['telefono']) ? htmlspecialchars($_POST['telefono']) : '';
    $solicitud = isset($_POST['solicitud']) ? htmlspecialchars($_POST['solicitud']) : '';

    // Preparar e insertar
    $stmt = $conn->prepare("INSERT INTO solicitudes (nombre, correo, telefono, solicitud) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        $msg = "<p id='mensaje' style='color:red; text-align:center;'>Error en la preparación de la consulta: " . htmlspecialchars($conn->error) . "</p>";
    } else {
        $stmt->bind_param("ssss", $nombre, $correo, $telefono, $solicitud);

        if ($stmt->execute()) {
            $msg = "<p id='mensaje' style='color:blue; font-weight:bold; text-align:center;'>Solicitud enviada y guardada exitosamente.</p>";
        } else {
            $msg = "<p id='mensaje' style='color:red; text-align:center;'>Error al guardar la solicitud: " . htmlspecialchars($stmt->error) . "</p>";
        }

        $stmt->close();
    }
} else {
    // Si se accede por GET, opcionalmente redirigir o mostrar un mensaje
    // header("Location: index.html");
    // exit();
    $msg = "<p id='mensaje' style='text-align:center;'>Accede desde el formulario para enviar datos.</p>";
}

$conn->close();

// Imprimir el HTML resultante con HEREDOC (evita problemas con comillas)
echo <<<HTML
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Resultado del envío</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <div class="logo">
      <img src="logo.png" alt="Logo">
    </div>

    {$msg}

    <div style="text-align:center; margin-top:20px;">
      <a href="index.html" style="text-decoration:none; color:white; background-color:rgba(3,23,176,0.65); padding:10px 15px; border-radius:5px;">Volver al formulario</a>
    </div>
  </div>
</body>
</html>
HTML;
